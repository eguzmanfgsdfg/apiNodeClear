const jtw = require('jsonwebtoken');

const generarJWT = (sessionKey = '', uid = '') => {
    return new Promise((resolve, reject) => {
        const payload = { sessionKey, uid };
        jtw.sign(payload, process.env.SECRETORPRIVATEKEY, { expiresIn: '30d' },
            (err, token) => {
                if (err) {
                    console.log(err);
                    reject('No se puedo generar el token');
                } else {
                    resolve(token);
                }
            });
    });
};


const isString = (str = '') => {
    const pattern = new RegExp(/^[A-Za-z\s]+$/g);
    return pattern.test(str);
};

const isInt = (str = '') => {
    const pattern = new RegExp(/^[0-9\s]+$/g);
    return pattern.test(str);
};

const isStringOrInt = (str = '') => {
    const pattern = new RegExp(/^[A-Za-z0-9\s]+$/g);
    return pattern.test(str);
};
const isCurrency = (str = '') => {
    const pattern = new RegExp(/^[0-9]{1,7}\.[0-9]{1,5}$/);
    return pattern.test(str);
};

;
const isEmail = (str = '') => {
    const pattern = new RegExp(/^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/);
    return pattern.test(str);
};

const isDateTime = (str = '') => {
    console.log("date asas [" + Date.parse(str, "dd/MM/yyyy HH:mm:ss") +"]");
    return  Date.parse(str, "dd/MM/yyyy HH:mm:ss")
};


module.exports = {
    isStringOrInt   ,
    isString,
    isInt ,
    isCurrency,
    generarJWT,
    isDateTime,
    isEmail
}
const express = require('express');
const cors = require('cors');

class Server {
    constructor(){
        console.log('Servidor en el puerto constructor');

        this.app = express();
        this.port = process.env.PORT || 5000;
        this.paths = {
            authorization: '/v1/authorization/',
            updateRequest: '/v1/updateRequest',
            riskLevel: '/v1/riskLevel',
            response: '/v1/response'
        };
        this.middlewares();
        this.routes();
    }
    middlewares(){
        console.log('Servidor en el puerto middlewares');

        this.app.use(cors());
        this.app.use(express.json());
    }
    routes(){
        console.log('Servidor en el puerto routes');

        this.app.use(this.paths.authorization, require('../routes/login'));
        this.app.use(this.paths.updateRequest, require('../routes/updateRequest'));
        this.app.use(this.paths.riskLevel, require('../routes/riskLevel'));
        this.app.use(this.paths.response, require('../routes/response'));
    }
    listen(){
        
     //   this.app.set('trust proxy', true);
        this.app.listen(this.port, () => {
            console.log('Servidor en el puerto', this.port);
        });
    }
}

module.exports = Server;